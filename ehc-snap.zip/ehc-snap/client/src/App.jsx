import React, {useState, useRef} from 'react';

export default function App(){
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [preview, setPreview] = useState(null);
  const [format, setFormat] = useState('png');
  const imgRef = useRef(null);

  async function handleCapture(e){
    e && e.preventDefault();
    setError('');
    if(!url) return setError('URL দেন।');
    try{
      setLoading(true);
      setPreview(null);
      const res = await fetch('/api/screenshot', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ url, format, fullPage: true })
      });
      if(!res.ok){
        const data = await res.json().catch(()=>({}));
        throw new Error(data.error || 'Server error');
      }
      const blob = await res.blob();
      const blobUrl = URL.createObjectURL(blob);
      setPreview(blobUrl);

      // auto-download after preview ready (optional)
      // const a = document.createElement('a');
      // a.href = blobUrl; a.download = `screenshot.${format}`; document.body.appendChild(a); a.click(); a.remove();

    }catch(err){
      console.error(err);
      setError(err.message || 'Failed');
    }finally{
      setLoading(false);
    }
  }

  function handleDownload(){
    if(!preview) return;
    const a = document.createElement('a');
    a.href = preview;
    a.download = `screenshot.${format}`;
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  return (
    <div style={{minHeight:'100vh', background:'#0f172a', color:'#e6eef8', display:'flex', alignItems:'center', justifyContent:'center', padding:20}}>
      <div style={{width:'100%', maxWidth:880, background:'#071032', borderRadius:16, padding:20, boxShadow:'0 10px 30px rgba(2,6,23,0.6)'}}>
        <h1 style={{fontSize:22, marginBottom:6}}>EHC Snap — Web Screenshot Generator</h1>
        <p style={{color:'#9fb0d9', marginBottom:16}}>URL বসাও, Capture করো — Preview দেখো, তারপর Download। শুধুমাত্র তোমার জন্য।</p>

        <form onSubmit={handleCapture} style={{display:'flex', gap:8, marginBottom:12}}>
          <input value={url} onChange={e=>setUrl(e.target.value)} placeholder="e.g. example.com or https://example.com" style={{flex:1, padding:10, borderRadius:10, border:'1px solid #123', background:'#07112a', color:'#e6eef8'}} />
          <select value={format} onChange={e=>setFormat(e.target.value)} style={{padding:10, borderRadius:10, background:'#07112a', color:'#e6eef8', border:'1px solid #123'}}>
            <option value="png">PNG (default)</option>
            <option value="jpg">JPG</option>
          </select>
          <button type="submit" disabled={loading} style={{padding:'10px 14px', borderRadius:10, background:'#0ea5ff', color:'#001', fontWeight:600}}>
            {loading ? 'Processing...' : 'Capture'}
          </button>
        </form>

        {error && <div style={{color:'#ffb4b4', marginBottom:8}}>{error}</div>}

        {preview ? (
          <div style={{marginTop:12}}>
            <div style={{display:'flex', gap:8, justifyContent:'space-between', alignItems:'center', marginBottom:8}}>
              <div style={{color:'#9fb0d9'}}>Preview</div>
              <div>
                <button onClick={handleDownload} style={{padding:'8px 12px', borderRadius:8, background:'#22c55e', color:'#002', fontWeight:600, marginRight:8}}>Download</button>
                <button onClick={()=>{URL.revokeObjectURL(preview); setPreview(null);}} style={{padding:'8px 12px', borderRadius:8, background:'#94a3b8'}}>Clear</button>
              </div>
            </div>
            <div style={{maxHeight:520, overflow:'auto', border:'1px solid #123', borderRadius:8, padding:8, background:'#07122b'}}>
              <img ref={imgRef} src={preview} alt="screenshot preview" style={{width:'100%', display:'block', borderRadius:6}} />
            </div>
          </div>
        ) : (
          <div style={{marginTop:12, color:'#98a6c7'}}>No preview yet — capture a URL.</div>
        )}

        <footer style={{marginTop:18, color:'#7f9ab8', fontSize:12}}>Built by E.H.C — Use responsibly. This demo is rate-limited.</footer>
      </div>
    </div>
  );
}