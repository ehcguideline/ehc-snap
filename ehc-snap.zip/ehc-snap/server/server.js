require('dotenv').config();
const express = require('express');
const cors = require('cors');
const puppeteer = require('puppeteer');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json({ limit: '2mb' }));

// Rate limiting - adjust as needed
const limiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 6,
});
app.use(limiter);

app.get('/api/health', (req, res) => res.json({ ok: true }));

app.post('/api/screenshot', async (req, res) => {
  try {
    let { url, width = 1366, height = 768, format = 'png', fullPage = true } = req.body;
    if (!url) return res.status(400).json({ error: 'Missing url in body' });

    try {
      url = url.startsWith('http') ? url : `https://${url}`;
      new URL(url);
    } catch (e) {
      return res.status(400).json({ error: 'Invalid URL' });
    }

    // Launch puppeteer. Use no-sandbox flags for many cloud hosts.
    const browser = await puppeteer.launch({
      args: ['--no-sandbox', '--disable-setuid-sandbox'],
      headless: true,
    });

    const page = await browser.newPage();
    await page.setViewport({ width: Number(width), height: Number(height) });

    // Go to the page and wait until network idle for stability
    await page.goto(url, { waitUntil: 'networkidle2', timeout: 60000 });

    // Small delay for heavy AJAX pages
    await page.waitForTimeout(1200);

    // Optionally scroll to bottom slowly to allow lazy loading (useful for long pages)
    if (fullPage) {
      await autoScroll(page);
    }

    const buffer = await page.screenshot({ fullPage: Boolean(fullPage), type: format === 'jpg' ? 'jpeg' : 'png' });

    await browser.close();

    res.set('Content-Type', format === 'jpg' ? 'image/jpeg' : 'image/png');
    res.set('Content-Disposition', `attachment; filename="screenshot.${format}"`);
    return res.send(buffer);
  } catch (err) {
    console.error('Screenshot error:', err);
    return res.status(500).json({ error: 'Failed to capture screenshot', detail: err.message });
  }
});

// utility: auto scroll
async function autoScroll(page){
  await page.evaluate(async () => {
    await new Promise((resolve) => {
      var totalHeight = 0;
      var distance = 500;
      var timer = setInterval(() => {
        var scrollHeight = document.body.scrollHeight;
        window.scrollBy(0, distance);
        totalHeight += distance;
        if(totalHeight >= scrollHeight - window.innerHeight){
          clearInterval(timer);
          resolve();
        }
      }, 250);
    });
  });
}

// Serve static frontend build if exists
const clientBuildPath = path.join(__dirname, '..', 'client', 'dist');
app.use(express.static(clientBuildPath));
app.get('/', (req, res) => {
  const index = path.join(clientBuildPath, 'index.html');
  if (require('fs').existsSync(index)) return res.sendFile(index);
  res.json({ ok: true, message: 'Screenshot API running' });
});

app.listen(PORT, () => console.log(`🚀 Screenshot API listening on port ${PORT}`));