# ehc-snap (Advanced Pro)
Web Screenshot Generator — React (client) + Node/Express + Puppeteer (server)

## Structure
- server/   -> backend (puppeteer)
- client/   -> frontend (vite + react)

## Quick local dev
### Server
cd server
npm install
node server.js

### Client
cd client
npm install
npm run dev

### Notes
- For production deploy, use Render (server) and Vercel (client).
- Puppeteer needs Chrome on many hosts; using --no-sandbox flags for typical cloud hosts.
- Make sure to set environment variables / adjust rate limits before public use.